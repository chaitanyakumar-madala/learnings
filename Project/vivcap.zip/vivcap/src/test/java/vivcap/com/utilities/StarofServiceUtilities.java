package vivcap.com.utilities;

import java.util.Calendar;
import java.util.TimeZone;

public class StarofServiceUtilities {

	public String datetimelocator() {
		String datetimeyear=null;
		String day=null;
		String month = null;
		Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
		
		switch(calendar.get(Calendar.DAY_OF_WEEK)) {
		case 1 : 
			day="Sunday";
			break;
		case 2 : 
			day="Monday";
			break;
		case 3 : 
			day="Tuesday";
			break;
		case 4 : 
			day="Wednesday";
			break;
		case 5 : 
			day="Thursday";
			break;
		case 6 : 
			day="Friday";
			break;
		case 7 : 
			day="Satruday";
			break;



		}
		switch(calendar.get(Calendar.MONTH)+1) {
		case 1:month="January";
				break;
		case 2:month="February";
		break;
		case 3:month="March";
		break;
		case 4:month="April";
		break;
		case 5:month="May";
		break;
		case 6:month="June";
		break;
		case 7:month="July";
		break;
		case 8:month="August";
		break;
		case 9:month="September";
		break;
		case 10:month="October";
		break;
		case 11:month="November";
		break;
		case 12:month="December";
		break;
		}
		datetimeyear=day+", "+month+" "+calendar.get(Calendar.DATE)+", "+calendar.get(Calendar.YEAR);
		return datetimeyear;
	}
	
	public String seconddayfromNow() {
		String day=null;
		String month = null;
		Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
		calendar.add(Calendar.DAY_OF_YEAR, 2);
		switch(calendar.get(Calendar.DAY_OF_WEEK)) {
		case 1 : 
			day="Sunday";
			break;
		case 2 : 
			day="Monday";
			break;
		case 3 : 
			day="Tuesday";
			break;
		case 4 : 
			day="Wednesday";
			break;
		case 5 : 
			day="Thursday";
			break;
		case 6 : 
			day="Friday";
			break;
		case 7 : 
			day="Satruday";
			break;

		}
		switch(calendar.get(Calendar.MONTH)+1) {
		case 1:month="January";
				break;
		case 2:month="February";
		break;
		case 3:month="March";
		break;
		case 4:month="April";
		break;
		case 5:month="May";
		break;
		case 6:month="June";
		break;
		case 7:month="July";
		break;
		case 8:month="August";
		break;
		case 9:month="September";
		break;
		case 10:month="October";
		break;
		case 11:month="November";
		break;
		case 12:month="December";
		break;
		}
		
		String next2day=day+", "+month+" "+calendar.get(Calendar.DATE)+", "+calendar.get(Calendar.YEAR);
		return next2day;
	}
	
	public boolean leapyearcheck() {
		Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
		int year=calendar.get(Calendar.YEAR);
		boolean leap = false;

        if(year % 4 == 0)
        {
            if( year % 100 == 0)
            {
                // year is divisible by 400, hence the year is a leap year
                if ( year % 400 == 0)
                    leap = true;
                else
                    leap = false;
            }
            else
                leap = true;
        }
        else
            leap = false;
	
	if(leap)
       return true;
    else
        return false;
}
	
}
