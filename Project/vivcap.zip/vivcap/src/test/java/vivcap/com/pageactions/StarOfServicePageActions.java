package vivcap.com.pageactions;

import java.util.Calendar;
import java.util.TimeZone;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import vivcap.com.appdriver.WebDriverUtils;
import vivcap.com.pages.StarOfServicePage;
import vivcap.com.utilities.StarofServiceUtilities;

public class StarOfServicePageActions extends StarOfServicePage {

	static WebDriver driver;
	static WebDriverUtils utl= new WebDriverUtils();
	public StarOfServicePageActions(WebDriver driver) {
		StarOfServicePageActions.driver = driver;
	}

	public static void launchURL(String url) {
		try {
			driver.get(url);
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

	public static void enterCity(String cityname) {
		try {
			
			getCityTextFiled().clear();
			getCityTextFiled().sendKeys(cityname);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}

	}

	public static void clickGo() {
		try {
			getGoButton().click();
		
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
	
	

	public static void clickNextButton() {
		try {
			
			getNextButton1().click();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

	public static void slectProblems(String slectProblem) {
		try {
			driver.findElement(By.xpath(
					"//label/input[@name='The problems are to do with which of the following things?']/parent::label/div[@class='styles__iconContainer___1sNdo']/following::div[contains(text(),'"
							+ slectProblem + "')]"))
					.click();
			// getSelectProblem().click();
			getNextbtnafterqstns().click();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

	public static void selectNeed(String need) {
		try {
			driver.findElement(By.xpath(
					"//label/input[@name='What do you need done?']/parent::label/div[@class='styles__iconContainer___1sNdo']/following::div[contains(text(),'"
							+ need + "')]"))
					.click();
			// getNeed().click();
			getNextButton1().click();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

	public static void problemYouhave(String problemyouhave) {
		try {
			driver.findElement(By.xpath(
					"//label/input[@name='What problem(s) do you have?']/parent::label/div[@class='styles__iconContainer___1sNdo']/following::div[contains(text(),'"
							+ problemyouhave + "')]"))
					.click();
			// getProblemyouhave().click();
			getNextButton1().click();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

	public static void plumberneedstoKnow(String message) {
		try {
			getProblemMessage().clear();
			getProblemMessage().sendKeys(message);
			clickNextButton();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

	public static void clickonNextafterqstns() {
		try {
			getNextbtnafterqstns().click();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

	public static void technicianDate(String datemsg) {
		try {
			driver.findElement(By.xpath(
					"//label/input[@name='When do you require plumbing?']/parent::label/div[@class='styles__iconContainer___1sNdo']/following::div[contains(text(),'"
							+ datemsg + "')]"))
					.click();
			// getTechtime().click();
			getNextButton1().click();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

	public static void requiredDate() {
		StarofServiceUtilities star = new StarofServiceUtilities();
		try {
			Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
			if (calendar.get(Calendar.MONTH) + 1 == 1 || calendar.get(Calendar.MONTH) + 1 == 3
					|| calendar.get(Calendar.MONTH) + 1 == 5 || calendar.get(Calendar.MONTH) + 1 == 7
					|| calendar.get(Calendar.MONTH) + 1 == 8 || calendar.get(Calendar.MONTH) + 1 == 10
					|| calendar.get(Calendar.MONTH) + 1 == 12) {
				{
					if (calendar.get(Calendar.DATE) == 30 || calendar.get(Calendar.DATE) == 31) {
						getNextArrow().click();
						driver.findElement(By.xpath("//button[@aria-label='" + star.seconddayfromNow() + "']")).click();

					} else {
						driver.findElement(By.xpath("//button[@aria-label='" + star.seconddayfromNow() + "']")).click();
					}
				}
				if (calendar.get(Calendar.MONTH) + 1 == 4 || calendar.get(Calendar.MONTH) + 1 == 6
						|| calendar.get(Calendar.MONTH) + 1 == 9 || calendar.get(Calendar.MONTH) + 1 == 11) {
					if (calendar.get(Calendar.DATE) == 29 || calendar.get(Calendar.DATE) == 30) {
						getNextArrow().click();
						driver.findElement(By.xpath("//button[@aria-label='" + star.seconddayfromNow() + "']")).click();

					} else {
						driver.findElement(By.xpath("//button[@aria-label='" + star.seconddayfromNow() + "']")).click();
					}
				}
				if (calendar.get(Calendar.MONTH) + 1 == 2 && star.leapyearcheck() == true) {
					if (calendar.get(Calendar.DATE) == 28 || calendar.get(Calendar.DATE) == 29) {
						getNextArrow().click();
						driver.findElement(By.xpath("//button[@aria-label='" + star.seconddayfromNow() + "']")).click();

					} else {
						driver.findElement(By.xpath("//button[@aria-label='" + star.seconddayfromNow() + "']")).click();
					}
				}
				if (calendar.get(Calendar.MONTH) + 1 == 2 && star.leapyearcheck() == false) {
					if (calendar.get(Calendar.DATE) == 27 || calendar.get(Calendar.DATE) == 28) {
						getNextArrow().click();
						driver.findElement(By.xpath("//button[@aria-label='" + star.seconddayfromNow() + "']")).click();

					} else {
						driver.findElement(By.xpath("//button[@aria-label='" + star.seconddayfromNow() + "']")).click();
					}
				}
			}
			getNextButton1().click();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
	
	public static void selectTime() {
		try {
			Select time = new Select(getSelectTime());
			time.selectByIndex(2);
			getDuration().sendKeys("4");
			getNextButton1().click();
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
}
