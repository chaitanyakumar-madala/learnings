package vivcap.com.testcases;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import vivcap.com.appdriver.WebDriverUtils;
import vivcap.com.pageactions.StarOfServicePageActions;

public class StarofServiceTests extends WebDriverUtils {

	WebDriver driver;

	@BeforeClass
	public void launchBrowser() throws IOException {
		driver = initiateDriver();
	}

	@Test
	public void startTestcase() throws IOException, InterruptedException {
		FileReader reader = new FileReader("resources/testdata.properties");
		Properties p = new Properties();
		p.load(reader);

		// can pass data from various sources
		final String url = "https://www.starofservice.in/dir/telangana/hyderabad/hyderabad/plumbing#/";
		final String cityname = p.getProperty("city");
		final String problem = p.getProperty("problem");
		final String need = p.getProperty("need");
		final String problemyouhave = p.getProperty("problemyouhave");
		final String message = "Test message";
		final String datemessage = p.getProperty("datemessage");
		PageFactory.initElements(driver, StarOfServicePageActions.class);
		// launch URL
		StarOfServicePageActions.launchURL(url);
		// driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		// Enter City name
		StarOfServicePageActions.enterCity(cityname);

		// click Go
		Thread.sleep(2000);
		StarOfServicePageActions.clickGo();
		
		// click Next
		Thread.sleep(2000);
		StarOfServicePageActions.clickNextButton();

		Thread.sleep(2000);
		// select Problem
		StarOfServicePageActions.slectProblems(problem);

		Thread.sleep(2000);
		// select need
		StarOfServicePageActions.selectNeed(need);

		Thread.sleep(2000);
		// select problemyouhave
		StarOfServicePageActions.problemYouhave(problemyouhave);

		Thread.sleep(2000);
		// Enter message to technician
		StarOfServicePageActions.plumberneedstoKnow(message);

		// select type of date for technician
		Thread.sleep(2000);
		StarOfServicePageActions.technicianDate(datemessage);

		// Selcte date for technician
		Thread.sleep(2000);
		StarOfServicePageActions.requiredDate();

		// Select time
		Thread.sleep(2000);
		StarOfServicePageActions.selectTime();
	}

	@AfterClass
	public void closeDriver() {
		quitDriver();
	}

}
